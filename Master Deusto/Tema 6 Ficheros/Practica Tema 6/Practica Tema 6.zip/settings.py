#Fichero con las rutas para el acceso a datos de cada liga

espana = "https://raw.githubusercontent.com/openfootball/football.json/master/2020-21/es.1.clubs.json"
alemania = "https://raw.githubusercontent.com/openfootball/football.json/master/2020-21/de.1.clubs.json"
italia = "https://raw.githubusercontent.com/openfootball/football.json/master/2020-21/it.1.clubs.json"
austria = "https://raw.githubusercontent.com/openfootball/football.json/master/2020-21/at.2.clubs.json"
inglaterra = "https://raw.githubusercontent.com/openfootball/football.json/master/2020-21/en.1.clubs.json"